package controller;

public enum ActionType {
    GET, POST
}
