package util;

public class Fields {

    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String CAPACITY = "Capacity";
    public static final String LOGIN = "login";
    public static final String FIRST_NAME = "first_name";
    public static final String LAST_NAME = "last_name";
    public static final String PATRONYMIC = "patronymic";
    public static final String ROLE_TYPE = "role_type";
    public static final String PASSWORD = "password";
    public static final String ENROLLMENT_TYPE = "enrollment_type";
    public static final String START_DATE = "start_date";
    public static final String END_DATE = "end_date";
    public static final String FACULTY_ID = "faculty_id";
    public static final String APPLICANT_ID = "applicant_id";
    public static final String TOTAL_RATING = "total_rating";
    public static final String STATE_TYPE = "state_type";
    public static final String GRADE = "grade";
    public static final String ENROLLMENT_ID = "enrollment_id";
}
