package model.dao.exception;

public class UserDaoException extends DaoException{
    private static final long serialVersionUID= -8062484171660935031L;

    public UserDaoException(String message) {
        super(message);
    }
}
