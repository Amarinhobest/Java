package model.dao.exception;

public class EnrollmentDaoException extends DaoException {

    private static final long serialVersionUID= 930374717751043958L;

    public EnrollmentDaoException(String message) {
        super(message);
    }
}
