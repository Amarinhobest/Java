package model.dao.exception;

public class DaoException extends Exception {

    private static final long serialVersionUID= -4854972581204568010L;

    public DaoException(String message) {
        super(message);
    }
}
