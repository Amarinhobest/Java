package model.dao.exception;

public class SubjectDaoException extends DaoException {

    private static final long serialVersionUID= 36230863735874051L;

    public SubjectDaoException(String message) {
        super(message);
    }
}
