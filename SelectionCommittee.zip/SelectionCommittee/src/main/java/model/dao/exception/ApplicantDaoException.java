package model.dao.exception;

public class ApplicantDaoException extends DaoException {

    private static final long serialVersionUID= 2377251927109800757L;

    public ApplicantDaoException(String message) {
        super(message);
    }
}
