package model.dao.exception;

public class FacultyDaoException extends DaoException {

    private static final long serialVersionUID= 1389928665866774843L;

    public FacultyDaoException(String message) {
        super(message);
    }
}
