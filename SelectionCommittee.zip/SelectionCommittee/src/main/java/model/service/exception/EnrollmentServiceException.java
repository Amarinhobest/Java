package model.service.exception;

public class EnrollmentServiceException extends ServiceException {

    private static final long serialVersionUID = 7966809992317883530L;

    public EnrollmentServiceException(String message) {
        super(message);
    }
}
