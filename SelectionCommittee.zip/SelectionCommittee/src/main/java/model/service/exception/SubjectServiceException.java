package model.service.exception;

public class SubjectServiceException extends ServiceException {

    private static final long serialVersionUID = 7663391606714118808L;

    public SubjectServiceException(String message) {
        super(message);
    }


}

