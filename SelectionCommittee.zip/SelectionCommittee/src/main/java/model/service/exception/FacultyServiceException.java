package model.service.exception;

public class FacultyServiceException extends ServiceException {

    private static final long serialVersionUID = 3658115017534913862L;

    public FacultyServiceException(String message) {
        super(message);
    }
}
