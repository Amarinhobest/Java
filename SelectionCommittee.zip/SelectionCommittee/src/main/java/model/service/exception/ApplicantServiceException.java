package model.service.exception;

public class ApplicantServiceException extends ServiceException {

    private static final long serialVersionUID = -6909988332087701031L;

    public ApplicantServiceException(String message) {
        super(message);
    }

}
